var ffmpeg = require('../index');

let file = "Pani Da Rang (Video Song) _ Vicky Donor _ Ayushmann Khurrana & Yami Gautam.mp4";

// make sure you set the correct path to your video file
var proc = ffmpeg("/home/varaprasadh/Videos/Pani Da Rang (Video Song) _ Vicky Donor _ Ayushmann Khurrana & Yami Gautam.mp4")
  // set video bitrate
  .videoBitrate(1024)
  // set target codec
  // set aspect ratio
  .aspect('16:9')
  // set size in percent
  .size('50%')
  // set fps
  .fps(24)
  // set audio bitrate
  .audioBitrate('128k')
  // set audio codec
  .audioCodec('libmp3lame')
  // set number of audio channels
  .audioChannels(2)
  // set custom option
  // set output format to force
  .format('avi')
  // setup event handlers
  .on('end', function() {
    console.log('file has been converted succesfully');
  })
  .on('progress',(progress=>{
    console.log("progreess",progress)
  }))
  .on('error', function(err) {
    console.log('an error happened: ' + err.message);
  })
  // save to file
  .save('/home/varaprasadh/Desktop/testinh.avi');
